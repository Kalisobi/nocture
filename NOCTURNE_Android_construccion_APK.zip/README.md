# NOCTURNE 1.1 — reproductor local Android

Proyecto Android nativo para reproducir archivos de audio locales.

## Funciones incluidas
- Selector de audio del teléfono mediante Storage Access Framework (no solicita acceso general a todos tus archivos).
- Cola de reproducción y selección de pistas.
- Reproducir, pausar, anterior, siguiente y barra de progreso.
- Reproducción gestionada por `MediaSessionService`, con controles multimedia del sistema/notificación y continuidad al salir de la pantalla.
- Lectura de metadatos y carátulas incrustadas cuando el archivo y el extractor las proporcionan.
- Ecualizador gráfico de cinco bandas usando el efecto de audio del sistema Android; disponibilidad y compatibilidad dependen del dispositivo y de la ruta de audio.
- Ajustes de ecualizador guardados localmente.

## Compilar
1. Descomprime el ZIP.
2. Abre la carpeta `NocturneAndroid` con Android Studio.
3. Espera la sincronización de Gradle.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Instala el APK generado en `app/build/outputs/apk/debug/app-debug.apk`.

## Notas
- El proyecto necesita descargar dependencias de Gradle desde los repositorios configurados.
- El ecualizador depende de que Android y el dispositivo permitan aplicar `android.media.audiofx.Equalizer` a la sesión de audio.
- Los controles en pantalla funcionan mientras la app está abierta; el servicio de sesión permite la reproducción en segundo plano y controles del sistema.
- Esta entrega es código fuente preparado para abrirse y compilarse en Android Studio; no se ha ejecutado una compilación Android en este entorno.


## Generar el APK mediante GitHub Actions
Se incluye `.github/workflows/android.yml`. Para generar el APK:
1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de esta carpeta al repositorio, en la rama `main`.
3. Abre la pestaña **Actions** y ejecuta **Build NOCTURNE APK** (o espera al build automático tras subir cambios).
4. Al finalizar, abre la ejecución y descarga el artefacto **NOCTURNE-debug-apk**.
5. Descomprime el artefacto y abre `app-debug.apk` en tu Samsung para instalarlo.

El APK generado por este flujo será una compilación de depuración, no una versión firmada para distribución en Play Store.
