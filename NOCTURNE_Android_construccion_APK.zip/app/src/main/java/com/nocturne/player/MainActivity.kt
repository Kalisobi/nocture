package com.nocturne.player

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {
    private data class Song(val uri: Uri, val name: String)
    private val songs = mutableListOf<Song>()
    private lateinit var controllerFuture: ListenableFuture<MediaController>
    private var controller: MediaController? = null
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var playButton: Button
    private lateinit var progress: SeekBar
    private lateinit var currentTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var queueContainer: LinearLayout
    private lateinit var emptyQueue: TextView
    private lateinit var albumArt: ImageView
    private lateinit var eqContainer: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris?.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: SecurityException) {}
            val name = queryDisplayName(uri) ?: "Archivo de audio"
            if (songs.none { it.uri == uri }) songs.add(Song(uri, name))
        }
        refreshQueue()
        if (controller?.mediaItemCount == 0 && songs.isNotEmpty()) playSong(0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = findViewById(R.id.trackTitle)
        subtitle = findViewById(R.id.trackSubtitle)
        playButton = findViewById(R.id.playButton)
        progress = findViewById(R.id.progress)
        currentTime = findViewById(R.id.currentTime)
        totalTime = findViewById(R.id.totalTime)
        queueContainer = findViewById(R.id.queueContainer)
        emptyQueue = findViewById(R.id.emptyQueue)
        albumArt = findViewById(R.id.albumArt)
        eqContainer = findViewById(R.id.equalizerContainer)

        buildEqualizerControls()
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture.addListener({
            try {
                controller = controllerFuture.get()
                controller?.addListener(playerListener)
                updateTrackInfo()
            } catch (_: Exception) {
                subtitle.text = "No se pudo iniciar el reproductor"
            }
        }, ContextCompat.getMainExecutor(this))

        findViewById<Button>(R.id.addMusicButton).setOnClickListener {
            picker.launch(arrayOf("audio/*"))
        }
        playButton.setOnClickListener {
            val p = controller ?: return@setOnClickListener
            if (p.mediaItemCount == 0 && songs.isNotEmpty()) playSong(0)
            else if (p.isPlaying) p.pause() else p.play()
        }
        findViewById<Button>(R.id.previousButton).setOnClickListener {
            controller?.let { if (it.currentPosition > 3000) it.seekTo(0) else it.seekToPreviousMediaItem() }
        }
        findViewById<Button>(R.id.nextButton).setOnClickListener { controller?.seekToNextMediaItem() }
        progress.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seekBar?.let { controller?.seekTo(it.progress.toLong()) }
                dragging = false
            }
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {}
        })
        handler.post(updateProgress)
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playButton.text = if (isPlaying) "Ⅱ  PAUSAR" else "▶  REPRODUCIR"
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateTrackInfo() }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) { updateArtwork(mediaMetadata) }
        override fun onPlaybackStateChanged(playbackState: Int) { updateTrackInfo() }
    }

    private fun queryDisplayName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    private fun playSong(index: Int) {
        val p = controller ?: return
        if (index !in songs.indices) return
        val items = songs.map { song ->
            val metadata = MediaMetadata.Builder()
                .setTitle(song.name.substringBeforeLast('.', song.name))
                .build()
            MediaItem.Builder().setUri(song.uri).setMediaMetadata(metadata).build()
        }
        p.setMediaItems(items, index, 0L)
        p.prepare()
        p.play()
        updateTrackInfo()
    }

    private fun refreshQueue() {
        queueContainer.removeAllViews()
        emptyQueue.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE
        songs.forEachIndexed { index, song ->
            val row = TextView(this).apply {
                text = "${index + 1}.  ${song.name}"
                textSize = 14f
                setTextColor(0xFFEBE8F5.toInt())
                setPadding(14)
                setOnClickListener { playSong(index) }
            }
            queueContainer.addView(row)
        }
    }

    private fun updateTrackInfo() {
        val p = controller ?: return
        val metadata = p.mediaMetadata
        title.text = metadata.title ?: songs.getOrNull(p.currentMediaItemIndex)?.name?.substringBeforeLast('.') ?: "Selecciona una canción"
        subtitle.text = metadata.artist ?: "NOCTURNE  •  ${if (p.mediaItemCount > 0) p.currentMediaItemIndex + 1 else 0} / ${songs.size}"
        playButton.text = if (p.isPlaying) "Ⅱ  PAUSAR" else "▶  REPRODUCIR"
        updateArtwork(metadata)
    }

    private fun updateArtwork(metadata: MediaMetadata) {
        val bytes = metadata.artworkData
        if (bytes != null) {
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bitmap != null) albumArt.setImageBitmap(bitmap)
        } else if (metadata.artworkUri != null) {
            try {
                contentResolver.openInputStream(metadata.artworkUri!!)?.use {
                    albumArt.setImageBitmap(BitmapFactory.decodeStream(it))
                }
            } catch (_: Exception) {}
        }
    }

    private fun buildEqualizerControls() {
        val labels = listOf("Graves", "Medios-graves", "Medios", "Medios-agudos", "Agudos")
        val prefs = getSharedPreferences("nocturne_eq", MODE_PRIVATE)
        labels.forEachIndexed { index, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 5, 0, 5)
            }
            val heading = TextView(this).apply {
                text = "$label  ·  ${prefs.getInt("band_$index", 0) / 100.0} dB"
                setTextColor(0xFFECE8F5.toInt())
                textSize = 12f
            }
            val slider = SeekBar(this).apply {
                max = 2400
                progress = (prefs.getInt("band_$index", 0) + 1200).coerceIn(0, 2400)
                progressTintList = android.content.res.ColorStateList.valueOf(0xFFB9A7FF.toInt())
                thumbTintList = android.content.res.ColorStateList.valueOf(0xFFB9A7FF.toInt())
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val level = value - 1200
                        prefs.edit().putInt("band_$index", level).apply()
                        heading.text = "$label  ·  ${"%.1f".format(Locale.US, level / 100.0)} dB"
                        sendBroadcast(Intent(PlaybackService.ACTION_EQ).setPackage(packageName)
                            .putExtra(PlaybackService.EXTRA_BAND, index)
                            .putExtra(PlaybackService.EXTRA_LEVEL, level))
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            row.addView(heading)
            row.addView(slider)
            eqContainer.addView(row)
        }
    }

    private val updateProgress = object : Runnable {
        override fun run() {
            val p = controller
            if (!dragging && p != null) {
                val duration = p.duration.takeIf { it > 0 } ?: 0L
                progress.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                progress.progress = p.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                currentTime.text = formatTime(p.currentPosition)
                totalTime.text = if (duration > 0) formatTime(duration) else "0:00"
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun formatTime(ms: Long): String {
        val seconds = ms.coerceAtLeast(0) / 1000
        return String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateProgress)
        controller?.removeListener(playerListener)
        MediaController.releaseFuture(controllerFuture)
        controller = null
        super.onDestroy()
    }
}
