package com.nocturne.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.Equalizer
import android.os.Build
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var player: ExoPlayer? = null
    private var equalizer: Equalizer? = null

    private val eqReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_EQ) return
            val band = intent.getIntExtra(EXTRA_BAND, -1)
            val level = intent.getIntExtra(EXTRA_LEVEL, 0)
            val eq = equalizer ?: return
            if (band in 0 until eq.numberOfBands.toInt()) {
                val range = eq.bandLevelRange
                eq.setBandLevel(band.toShort(), level.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        mediaSession = MediaSession.Builder(this, exo).build()
        val filter = IntentFilter(ACTION_EQ)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(eqReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(eqReceiver, filter)
        }
        exo.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                attachEqualizer(exo.audioSessionId)
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (exo.audioSessionId != 0) attachEqualizer(exo.audioSessionId)
            }
        })
    }

    private fun attachEqualizer(sessionId: Int) {
        if (sessionId <= 0) return
        try {
            equalizer?.release()
            equalizer = Equalizer(0, sessionId).apply {
                enabled = true
                val prefs = getSharedPreferences("nocturne_eq", MODE_PRIVATE)
                for (band in 0 until numberOfBands.toInt()) {
                    val saved = prefs.getInt("band_$band", 0)
                    val range = bandLevelRange
                    setBandLevel(band.toShort(), saved.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
                }
            }
        } catch (_: Exception) {
            equalizer = null
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        try { unregisterReceiver(eqReceiver) } catch (_: Exception) {}
        equalizer?.release()
        player?.release()
        mediaSession?.release()
        mediaSession = null
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_EQ = "com.nocturne.player.ACTION_EQ"
        const val EXTRA_BAND = "band"
        const val EXTRA_LEVEL = "level"
    }
}
